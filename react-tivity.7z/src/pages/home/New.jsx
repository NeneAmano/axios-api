import {
    Button,
    Grid2,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
  } from "@mui/material";
  import EditIcon from "@mui/icons-material/Edit";
  import React, { useState } from "react";
  
  export const Home = () => {
    const [show, setShow] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
  
    const listOfUsers = [
      { firstName: "Angelo", age: 25, gender: "Male" },
      { firstName: "Jay", age: 22, gender: "Male" },
      { firstName: "Alex", age: 19, gender: "Male" },
      { firstName: "Gerald", age: 20, gender: "Male" },
      { firstName: "Paolo", age: 22, gender: "Male" },
    ];
  
  
    return (
      <Grid2
        container
        justifyContent={"center"}
        alignContent="center"
        alignItems={"center"}
      >
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Firsname</TableCell>
                <TableCell>Age</TableCell>
                <TableCell>Gender</TableCell>
                <TableCell>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {listOfUsers.map((user, index) => (
                <TableRow key={index}>
                  <TableCell>{user.firstName}</TableCell>
                  <TableCell>{user.age}</TableCell>
                  <TableCell>{user.gender}</TableCell>
                  <TableCell>
                    <Button>
                      <EditIcon fontSize="small" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        
      </Grid2>
    );
  };