import {
  Button,
  Grid2,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
  FormControl,
  TextField,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";

import React, { useState } from "react";

export const Home = () => {
  const [show, setShow] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [listOfUser, setListUser] = useState("");
  const [listOfUsers, setListUsers] = useState([
    { firstName: "Angelo", age: 25, gender: "Male" },
    { firstName: "Jay", age: 22, gender: "Male" },
    { firstName: "Alex", age: 19, gender: "Male" },
    { firstName: "Gerald", age: 20, gender: "Male" },
    { firstName: "Paolo", age: 22, gender: "Male" },
  ]);
  const [age, setFirstName] = useState("");
  const [firstName, setFirstName] = useState("");
  const [firstName, setFirstName] = useState("");


  const handleEditClick = (user) => {
    setSelectedUser(user);
    setShow(true);
  };

  const handleClose = () => {
    setShow(false);
    setSelectedUser(null);
  };

  const handleAddClick = (user) => {
    setShow(true);
    setListUser(true);
  };

  return (
    <Grid2
      container
      justifyContent={"center"}
      alignContent="center"
      alignItems={"center"}
    >
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Add</TableCell>
              <TableCell>Firstname</TableCell>
              <TableCell>Age</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {listOfUsers.map((user, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Button onClick={() => handleAddClick(user)}>
                    <AddIcon fontSize="small" />
                  </Button>
                </TableCell>
                <TableCell>{user.firstName}</TableCell>
                <TableCell>{user.age}</TableCell>
                <TableCell>{user.gender}</TableCell>
                <TableCell>
                  <Button onClick={() => handleEditClick(user)}>
                    <EditIcon fontSize="small" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {listOfUser && (
        <Dialog open={show} onClose={handleClose}>
          <DialogTitle>Edit User</DialogTitle>
          <DialogContent>
            <FormControl>
              <Typography>FirstName pls pakiusap</Typography>
              <TextField
                placeholder="Write your name here"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
              />
              {/* <button onClick={() => {
        listOfUsers([
          ...firstName,
          { name: listOfUser }
        ]);
      }}>Add</button> */}
            </FormControl>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Close</Button>
          </DialogActions>
        </Dialog>
      )}
      {selectedUser && (
        <Dialog open={show} onClose={handleClose}>
          <DialogTitle>Edit User</DialogTitle>
          <DialogContent>
            <Typography>Name: {selectedUser.firstName}</Typography>
            <Typography>Age: {selectedUser.age}</Typography>
            <Typography>Gender: {selectedUser.gender}</Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Close</Button>
          </DialogActions>
        </Dialog>
      )}
    </Grid2>
  );
};
